package com.expertzlab.ranklist;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface AnswerKeyReader {

	Map<String, Answer> readAnswerKeyMap();
	
	
	
}
