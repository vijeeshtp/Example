package com.expertzlab.ranklist;

import java.util.List;

public interface AnswerSheetProcessor {
	
	List<EvalutaionInfo> evaluateAnswerSheet();

}
