package com.expertzlab.ranklist;

import java.util.List;

public interface AnswerSheetReader {
	
	List <AnswerSheet> readAnswerSheet();

}
