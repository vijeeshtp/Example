package com.expertzlab.ranklist;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class IOAnswerKeyReader implements AnswerKeyReader {

	public Map<String,Answer> readAnswerKeyMap() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
