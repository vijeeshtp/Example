package com.expertzlab.ranklist;

public interface RankListWriter {

}
