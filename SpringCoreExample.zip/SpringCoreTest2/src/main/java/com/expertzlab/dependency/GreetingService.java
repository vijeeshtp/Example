package com.expertzlab.dependency;

public class GreetingService {

	
}
