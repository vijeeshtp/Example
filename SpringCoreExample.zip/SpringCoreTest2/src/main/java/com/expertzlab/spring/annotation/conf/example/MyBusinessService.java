package com.expertzlab.spring.annotation.conf.example;
public class MyBusinessService {
 
    public void runBusiness(){
        System.out.println("Executing business service.");
    }
}