package com.expertzlab.spring.annotation.conf.example;
public class OtherBusinessService {
 
    public void runBusiness(){
        System.out.println("Executing business service.");
    }
}