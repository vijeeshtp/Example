package com.expertzlab.spring.annotation.conf.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringDemo {

    public static void main(String a[]){
 
        ApplicationContext context = new AnnotationConfigApplicationContext(MyAppConfig.class);
        MyBusinessService businessService = (MyBusinessService) context.getBean("businessService");
        businessService.runBusiness();
        MyJdbcService jdbcService = (MyJdbcService) context.getBean("jdbcService");
        jdbcService.createJdbcConnection();
       
    }
}