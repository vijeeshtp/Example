package com.expertzlab.spring.autowire.annotation.example;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {

	String rollNo;
	@Autowired
	Address address;
	
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", address=" + address + "]";
	}
	
	
	
}
