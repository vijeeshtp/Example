package com.expertzlab.spring.autowire.example;

public class Address {
	String steet;
	String city;
	String state;
	
	@Override
	public String toString() {
		return "Address [steet=" + steet + ", city=" + city + ", state=" + state + "]";
	}
	public String getSteet() {
		return steet;
	}
	public void setSteet(String steet) {
		this.steet = steet;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
