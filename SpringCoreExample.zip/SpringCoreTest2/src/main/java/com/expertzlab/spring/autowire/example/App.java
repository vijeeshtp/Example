package com.expertzlab.spring.autowire.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.expertzlab.spring.dependency.example2.Greeting;

public class App {
	public static void main(String args[]){
	ApplicationContext context = new ClassPathXmlApplicationContext("bean-autowire.xml");
	Student student= (Student) context.getBean("student");
	System.out.println(student);
}
}
