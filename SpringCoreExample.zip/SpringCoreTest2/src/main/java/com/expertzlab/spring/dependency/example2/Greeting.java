package com.expertzlab.spring.dependency.example2;

public interface Greeting {

	void greet();
	
}
