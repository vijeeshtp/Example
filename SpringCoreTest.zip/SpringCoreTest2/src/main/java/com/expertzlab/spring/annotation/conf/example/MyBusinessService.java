package com.expertzlab.spring.annotation.conf.example;
public class MyBusinessService {
 
    public void runMyBusiness(){
        System.out.println("Running business...");
    }
}