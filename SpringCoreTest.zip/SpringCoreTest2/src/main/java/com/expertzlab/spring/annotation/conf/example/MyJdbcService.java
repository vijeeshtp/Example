package com.expertzlab.spring.annotation.conf.example;
public class MyJdbcService {
 
    public void createJdbcConnection(){
        System.out.println("Creating jdbc connections...");
    }
}