package com.expertzlab.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.expertzlab.model.Project;
import com.expertzlab.model.User;
import com.expertzlab.service.ProjectService;
import com.expertzlab.service.UserService;

@Controller("projectController")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
		
	@RequestMapping(value="/project", method = RequestMethod.GET)
	public ModelAndView project(){
		ModelAndView modelAndView = new ModelAndView();
		Project project = new Project();
		modelAndView.addObject("project", project);
		modelAndView.setViewName("project");
		return modelAndView;
	}
	
	@RequestMapping(value = "/project", method = RequestMethod.POST)
	public ModelAndView createNewProject(@Valid Project project, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		/*
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"User with this email already exists");
		}*/
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("project");
		} else {
			projectService.saveProject(project);
			modelAndView.addObject("successMessage", "Project has been created successfully");
			//modelAndView.addObject("user", new User());
			//modelAndView.setViewName("registration");
			modelAndView.setViewName("project");
		}
		return modelAndView;
	}

}