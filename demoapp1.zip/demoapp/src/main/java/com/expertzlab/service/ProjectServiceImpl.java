package com.expertzlab.service;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.expertzlab.model.Project;
import com.expertzlab.model.Role;
import com.expertzlab.model.User;
import com.expertzlab.repository.ProjectRepository;
import com.expertzlab.repository.RoleRepository;
import com.expertzlab.repository.UserRepository;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService{

	@Autowired
	private ProjectRepository projectRepository;
	
	
	@Override
	public void saveProject(Project project) {
		projectRepository.save(project);
	}


	@Override
	public List<Project> findAll() {
		 return projectRepository.findAll();
	}

}