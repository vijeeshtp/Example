package com.expertzlab.controller;
import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.expertzlab.model.Project;
import com.expertzlab.model.User;
import com.expertzlab.service.ProjectService;
import com.expertzlab.service.UserService;

@Controller("projectController")
public class ProjectController {
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private UserService userService;
		
	@RequestMapping(value="/project", method = RequestMethod.GET)
	public ModelAndView project(){
		ModelAndView modelAndView = new ModelAndView();
		Project project = new Project();
		modelAndView.addObject("project", project);
		modelAndView.addObject("users", userService.findAll());
		modelAndView.addObject("projects", projectService.findAll());
		modelAndView.setViewName("project");
		return modelAndView;
	}
	
	@RequestMapping(value = "/project", method = RequestMethod.POST)
	public ModelAndView createNewProject(@Valid Project project, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		/*
		User userExists = userService.findUserByEmail(user.getEmail());
		if (userExists != null) {
			bindingResult
					.rejectValue("email", "error.user",
							"User with this email already exists");
		}*/
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("project");
			modelAndView.addObject("projects", projectService.findAll());
		} else {
			projectService.saveProject(project);
			modelAndView.addObject("successMessage", "Project has been created successfully");
			//modelAndView.addObject("user", new User());
			//modelAndView.setViewName("registration");
			modelAndView.setViewName("project");
			modelAndView.addObject("projects", projectService.findAll());
		}
		return modelAndView;
	}
	
	
	@RequestMapping(value = "/project/update", method = RequestMethod.POST)
	public ModelAndView updateProject(@Valid Project project, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		
		if (bindingResult.hasErrors()) {
			modelAndView.setViewName("project-edit");
			modelAndView.addObject("projects", projectService.findAll());
		} else {
			projectService.saveProject(project);
			modelAndView.addObject("successMessage", "Project has been updated successfully");
			//modelAndView.addObject("user", new User());
			//modelAndView.setViewName("registration");
			modelAndView.setViewName("project-edit");
			modelAndView.addObject("projects", projectService.findAll());
		}
		return modelAndView;
	}
	
	
	
	@RequestMapping("/project/edit/{id}")
    public ModelAndView editView(@PathVariable("id") int id) {
        Project project = projectService.findById(id);
        ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("project", project);
		modelAndView.addObject("users", userService.findAll());
		modelAndView.addObject("projects", projectService.findAll());
		modelAndView.setViewName("project-edit");
		return modelAndView;
    }
	
	
	@RequestMapping("/project/delete/{id}")
    public ModelAndView deleteProject(@PathVariable("id") int id) {
        Project project = projectService.findById(id);
        projectService.deleteProject(project);
        ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("projects", projectService.findAll());
		modelAndView.setViewName("redirect:/project");
		return modelAndView;
    }
	
	
	@RequestMapping("/project/assign/{id}")
    public ModelAndView assignProject(@PathVariable("id") int id) {
        Project project = projectService.findById(id);
        ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("project", project);
		modelAndView.addObject("users", userService.findAll());
		modelAndView.setViewName("project-assign");
	    modelAndView.addObject("projectUsers", projectService.findById(project.getId()).getUsers());
		return modelAndView;
    }
	
	@RequestMapping("/project/assign/user")
    public ModelAndView assignUser(@Valid Project project, BindingResult bindingResult) {
        ModelAndView modelAndView = new ModelAndView();
        Project projectToBeUpdated = projectService.findById(project.getId());
        projectToBeUpdated.getUsers().addAll(project.getUsers());
        projectService.saveProject(projectToBeUpdated);  
        
        modelAndView.addObject("users", userService.findAll());
        modelAndView.addObject("projectUsers", projectService.findById(project.getId()).getUsers());
     
		modelAndView.setViewName("project-assign");
		return modelAndView;
    }
	
	
	

}