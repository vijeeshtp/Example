package com.expertzlab.service;
import java.util.List;
import java.util.Set;

import com.expertzlab.model.Project;

public interface ProjectService {
	public List<Project> findAll();
	public void saveProject(Project user);
	public Project findById(int Id);
	public void deleteProject (Project project);
}